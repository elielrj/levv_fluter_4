import 'package:levv4/model/bo/usuario/usuario.dart';
import 'package:levv4/model/dao/usuario/usuario_dao.dart';

class TelaSplashController {
  final usuarioDAO = UsuarioDAO();

  Future<Usuario> buscarUsuario() async {
    return await usuarioDAO.buscarUmUsuarioPeloNomeDoDocumento();
  }

  bool usuarioFirebaseEstaLogado() {
    return usuarioDAO.autenticacao.auth.currentUser != null ? true : false;
  }
}

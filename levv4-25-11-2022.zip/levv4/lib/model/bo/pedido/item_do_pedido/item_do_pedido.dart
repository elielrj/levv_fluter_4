import '../../endereco/endereco.dart';

class ItemDoPedido {
  int? ordem;
  Endereco? coleta;
  Endereco? entrega;

  ItemDoPedido({
    this.ordem,
    this.coleta,
    this.entrega
  });





}

import 'package:levv4/model/bo/usuario/perfil/acompanhar/acompanhar.dart';

class Administrar extends Acompanhar {

  Administrar(){
    perfil = "Administrar";
  }

}

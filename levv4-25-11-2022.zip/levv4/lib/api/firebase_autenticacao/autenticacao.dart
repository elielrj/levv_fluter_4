import 'package:firebase_auth/firebase_auth.dart';

import 'mixin_codigo_de_erro_do_firebase_auth.dart';
import 'mixin_nome_do_documento_do_usuario_corrente.dart';


class Autenticacao with

    CodigoDeErroDoFirebaseAuth {

  final FirebaseAuth _auth = FirebaseAuth.instance;

  FirebaseAuth get auth => _auth;


  String nomeDoDocumentoDoUsuarioCorrente( )  {



    var celular =  _auth.currentUser?.phoneNumber;
    var email =  _auth.currentUser?.email;

    String documentName = "";

    if(celular != null && celular != ""){
      documentName = celular.toString();
    }
    if(email != null && email != ""){
      documentName = email.toString();
    }

    return documentName;
  }

}

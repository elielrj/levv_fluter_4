import 'package:flutter/material.dart';

class ColorsLevv {
  static const Color FUNDO_400 = Color(0xff42A5F5);
  static const Color FUNDO_500_BUTTON_NOT_SELECTED = Color(0xff2196F3);
  static const Color FUNDO_200_BUTTON_SELECTED = Color(0xff90CAF9);
  static const Color TEXTO = Colors.white;
}

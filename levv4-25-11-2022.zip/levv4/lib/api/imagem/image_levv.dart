
import 'package:flutter/material.dart';

class ImageLevv{

  static const String LOGO_DO_APP_LEVV = "imagens/logo_levv.png";

  static const String REGISTER = "imagens/icon_register.png";
  static const String TRACK_DELIVERY = "imagens/icon_track_delivery.png";
  static const String SEND_PRODUCT = "imagens/icon_send_product.png";
  static const String MOTO_DELIVERY = "imagens/icon_motocycle_delivery.png";


  static const String ICON_ACTIVE = "imagens/icon_active.png";
  static const String ICON_FINISHED = "imagens/icon_finished.png";
  static const String ICON_PENDING = "imagens/icon_pending.png";


}
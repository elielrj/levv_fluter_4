
import 'package:flutter/material.dart';

class RouteLevv  {

  static const String TELA_SPLASH = "/splash";
  //static const String TELA_HOME = "/home";
  static const String TELA_ENVIAR = "/enviar";
  static const String TELA_ENTREGAR = "/entregar";

  static const String TELA_CADASTRAR_ENDERECO = "/cadastrar_endereco";

  static const String TELA_CADASTRAR_ACOMPANHADOR_DE_PEDIDO = "/cadastrar_acompanhador";
  static const String TELA_CADASTRAR_TRANSPORTADOR = "/cadastrar_transportador";
  static const String TELA_CADASTRAR_CLIENTE = "/cadastrar_cliente";
  static const String TELA_CADASTRAR_LOJISTA = "/cadastrar_lojista";
  static const String TELA_CADASTRAR_ADMINISTRADOR = "/cadastrar_administrador";

  static const String TELA_ACOMPANHAR = "/acompanhar";




}



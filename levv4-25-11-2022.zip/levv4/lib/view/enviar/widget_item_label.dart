import 'package:flutter/material.dart';

Widget widgetItemLabel(String label)=> Text(
  "Item: $label",
  style: const TextStyle(
    fontSize: 10,
    backgroundColor: Colors.white70,
  ),
);
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

mixin ListenToLocationUpdates {
/*
  late StreamSubscription<Position> positionStream;

  listenToLocationUpdates() async {

    positionStream
    = Geolocator.getPositionStream(
            distanceFilter: 10,
            desiredAccuracy: LocationAccuracy.high,
            timeLimit: const Duration(seconds: 30))
        .listen((Position position) {

    });
  }
  */
}
